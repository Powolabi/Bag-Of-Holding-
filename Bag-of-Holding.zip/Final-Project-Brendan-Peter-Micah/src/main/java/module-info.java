module edu.bsu.cs {

    exports edu.bsu.cs222;
}